import numpy as np
from scipy.signal import firwin

# Define filter parameters
sample_rate = 100  # Adjust based on your ADXL367 sampling rate (e.g., 100Hz)
low_cutoff = 0.5   # Lower cutoff frequency in Hz
high_cutoff = 5.0  # Upper cutoff frequency in Hz
num_taps = 64      # Filter order (must be even)

# Generate FIR band-pass filter coefficients
fir_coeffs = firwin(num_taps, [low_cutoff, high_cutoff], pass_zero=False, fs=sample_rate)

# Print coefficients in C array format
print("const float firCoeffs[{}] = {{".format(num_taps))
for i, coeff in enumerate(fir_coeffs):
    print("    {:.6f},".format(coeff), end=" ")
    if (i + 1) % 8 == 0:  # Format for readability
        print()
print("};")
