#ifndef _APP_COMMIT_H_
#define _APP_COMMIT_H_

/*  values come from cmake/version.cmake
 * BUILD_COMMIT related  values will be 'git rev-parse',
 * alternatively user defined BUILD_VERSION.
 */

#define APP_COMMIT                   e80846acd3c4
#define APP_COMMIT_STRING            "e80846acd3c4"

#endif /* _APP_COMMIT_H_ */
