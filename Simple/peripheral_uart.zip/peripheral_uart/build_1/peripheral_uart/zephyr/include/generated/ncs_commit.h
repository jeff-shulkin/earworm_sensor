#ifndef _NCS_COMMIT_H_
#define _NCS_COMMIT_H_

/*  values come from cmake/version.cmake
 * BUILD_COMMIT related  values will be 'git rev-parse',
 * alternatively user defined BUILD_VERSION.
 */

#define NCS_COMMIT                   a2386bfc8401
#define NCS_COMMIT_STRING            "a2386bfc8401"

#endif /* _NCS_COMMIT_H_ */
